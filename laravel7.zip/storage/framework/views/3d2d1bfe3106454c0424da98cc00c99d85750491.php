<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daftar Absen Siswa per Kelas</title>
    <!-- ✅ Bootstrap CSS CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<div class="container py-5">
    <h2 class="mb-4">Daftar Absen Siswa per Kelas</h2>

    <?php $__currentLoopData = $kelasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <strong>Kelas: <?php echo e($kelas->nama_kelas); ?>-<?php echo e($kelas->jurusan); ?></strong>
            </div>
            <div class="card-body">
                <?php
                    $siswaAbsen = $siswaSudahAbsen->get($kelas->id);
                ?>

                <?php if(!$siswaAbsen || $siswaAbsen->isEmpty()): ?>
                    <p class="text-muted">Belum ada siswa yang absen hari ini.</p>
                <?php else: ?>
                    <ul class="list-group">
                        <?php $__currentLoopData = $siswaAbsen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo e($siswa->nama); ?>

                                <span class="badge bg-success">Sudah Absen</span>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<!-- ✅ Bootstrap JS (opsional, hanya jika butuh interaktivitas) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel7\resources\views\kelas\absensi_siswa_tiap_kelas.blade.php ENDPATH**/ ?>