<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<h2>Reminder Deadline Tugas</h2>
<p>Judul: <strong><?php echo e($task->title); ?></strong></p>
<p>kelas :<strong><?php echo e($task->kelas->nama_kelas); ?></strong></p>
<h1>haiiiii</h1>
<p>Deadline: <?php echo e(\Carbon\Carbon::parse($task->deadline)->format('d M Y H:i')); ?></p>
<p>Jangan sampai telat ya!</p>

</body>
</html><?php /**PATH C:\xampp\htdocs\laravel7\resources\views\emails\deadline_reminder.blade.php ENDPATH**/ ?>