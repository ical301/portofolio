<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Data Tugas</title>

    <!-- Bootstrap CSS from CDN -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Optional: Additional stylesheets -->
    <style>
        table {
            width: 100%;
            margin-top: 20px;
        }
        table th, table td {
            text-align: center;
            vertical-align: middle;
        }
        .container {
            margin-top: 50px;
        }
        .btn-xs {
            padding: 0.25rem 0.4rem;
            font-size: 0.75rem;
            line-height: 1.2;
            border-radius: 0.2rem;
        }

    </style>
</head>
<body>
<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<form action="<?php echo e(route('export-pdf')); ?>" method="GET" class="mx-5 my-5 btn-export-ignore">
    <input type="hidden" name="kelas_id" value="<?php echo e($kelasId); ?>">
    <input type="hidden" name="mataPelajaran" value="<?php echo e($mataPelajaran); ?>">
    <button type="submit" class="btn btn-danger">
       Laporan nilai persiswa 
    </button>
</form>

<div class="container">
    <h2 class="mb-4 text-center">Materi <?php echo e($tugas->first()->title ?? 'Pilih Filter Tugas'); ?></h2>
    <!-- Responsive Table -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>No</th>
                    <th>Nama Siswa</th>
                    <th>jawaban Dari Siswa</th>
                    <th>Nilai</th>
                    <th>Tugas Dari Guru</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; ?>
                <?php $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tugas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $tugas->tugas_dari_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($jawaban->siswa->nama); ?></td>
                            <td>
                                <?php if($jawaban->file_url): ?>
                                    <a href="<?php echo e(asset('storage/' . $jawaban->file_url)); ?>" target="_blank">Lihat Tugas PDF</a>
                                <?php else: ?>
                                    Belum mengumpulkan
                                <?php endif; ?>
                            </td>
                            <td class="btn-export-ignore">
                                <?php if($jawaban->nilai !== null): ?>
                                    
                                    <span><?php echo e($jawaban->nilai); ?></span>
                                <?php else: ?>
                                    
                                    <form action="<?php echo e(route('berikan.nilai', $jawaban->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="siswa_id" value="<?php echo e($jawaban->siswa->id); ?>">
                                        <input type="number" name="nilai" class="form-control" value="<?php echo e(old('nilai')); ?>" min="0" max="100" step="1" required>
                                        <button type="submit" class="btn btn-sm btn-success mt-2 btn-xs">Simpan Nilai</button>
                                    </form>
                                <?php endif; ?>
                            </td>

                            <td><?php echo e($tugas->title); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>









<!-- Bootstrap JS from CDN -->
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel7\resources\views\nilai\TEST_filter_siswa.blade.php ENDPATH**/ ?>