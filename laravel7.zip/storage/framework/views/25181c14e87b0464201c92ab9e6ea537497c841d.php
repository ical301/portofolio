<!DOCTYPE html>
<html>
<head>
    <title>Export PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <h1>Data Pengguna</h1>
    <p>Nama: <?php echo e($name); ?></p>
    <p>Email: <?php echo e($email); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravel7\resources\views\pdf\export.blade.php ENDPATH**/ ?>