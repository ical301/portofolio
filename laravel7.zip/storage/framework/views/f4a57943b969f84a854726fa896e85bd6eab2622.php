<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
	<!-- Bootstrap CSS -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>
	<h2 class="text-center mb-3 mt-5 main-heading">Daftar Tugas Anda</h2>
	<p>Nama Pembuat : <?php echo e($user_name); ?></p>
	<div class="table-responsive">
	    <table class="table table-bordered table-hover table-striped align-middle">
	        <thead class="table-light">
	            <tr>
	                <th>ID</th>
	                <th>Judul</th>
	                <th>Deskripsi</th>
	                <th>Deadline</th>
	            </tr>
	        </thead>
	        <tbody>
	            <?php $__empty_1 = true; $__currentLoopData = $tugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	                <tr>
	                    <td><?php echo e($item->id); ?></td>
	                    <td><?php echo e($item->title); ?></td>
	                    <td><?php echo e(\Illuminate\Support\Str::limit($item->description, 50)); ?></td>
	                    <td><?php echo e(\Carbon\Carbon::parse($item->deadline)->format('d M Y H:i')); ?></td>
	                    <td><?php echo e($item->kelas->nama_kelas ?? 'Tidak ada kelas'); ?><?php echo e($item->kelas->jurusan); ?></td>
	                </tr>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	                <tr>
	                    <td colspan="4" class="text-center">Tidak ada data tugas.</td>
	                </tr>
	            <?php endif; ?>
	        </tbody>
	    </table>
	</div>
	<div></div>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel7\resources\views\tugas\show_tugas_dari_guru.blade.php ENDPATH**/ ?>