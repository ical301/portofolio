<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Tugas & Jawaban</title>

    <!-- ✅ Bootstrap 5 CDN CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-XwEi0uEiYbYQdBGQvd5b7T/FJNPn2SpqxKn4X9rZPRsHdJfRMpknIkdHU8t2Pmfa" crossorigin="anonymous">
</head>
<body>
    <h3>Input Nilai Tugas: <?php echo e($tugas->title); ?></h3>

    <form action="<?php echo e(route('input.nilai.simpan')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Nama Siswa</th>
                    <th>Jawaban</th>
                    <th>Nilai</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $tugas->tugas_dari_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jawaban): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($jawaban->siswa->nama); ?></td>
                        <td>
                            <a href="<?php echo e(asset($jawaban->file_jawaban)); ?>" target="_blank">Lihat Jawaban</a>
                        </td>
                        <td>
                            <input type="number" name="nilai[<?php echo e($jawaban->id); ?>]" value="<?php echo e($jawaban->nilai ?? ''); ?>" min="0" max="100" class="form-control" required>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-success">Simpan Nilai</button>
    </form>


    <!-- ✅ Bootstrap 5 CDN JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Qrj7CQOqAqYHTA8M41YF5NoN0V+a2PvD51Kh+nToR5KtnR9iHGP59VvM8XycH4FZ" crossorigin="anonymous"></script>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <title>Test Bootstrap</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="alert alert-success text-center">
            ✅  Anda berhasil mengumpulkan tugas!
        </div>
    </div>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\laravel7\resources\views\nilai\form_input_nilai.blade.php ENDPATH**/ ?>