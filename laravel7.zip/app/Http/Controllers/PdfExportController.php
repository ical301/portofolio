<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Tugas_dari_siswa;
use Illuminate\Support\Facades\Storage;
use App\Models\Tugas_dari_guru;
use App\Models\Siswa;
use App\Models\Kelas;
use Carbon\Carbon;
use PDF; // Import PDF facade

class PdfExportController extends Controller
{
    // public function exportPdf(Request $request)
    // {
    //     $kelasId = $request->input('kelas_id');
    //     $mataPelajaran = $request->input('mataPelajaran');
    //     $data = [
    //         'kelas_id' => $kelasId,
    //         'mata_pelajaran' => $mataPelajaran,
    //     ];
        
    //     $tugas = Tugas_dari_guru::with('tugas_dari_siswa.siswa') // Mengambil jawaban dari siswa beserta data siswa
    //         ->whereHas('kelas', function($query) use ($kelasId) {
    //             if ($kelasId) {
    //                 $query->where('id', $kelasId);
    //             }
    //         })
    //         ->when($mataPelajaran, function ($query) use ($mataPelajaran) {
    //             return $query->where('title', $mataPelajaran); 
    //         })
    //         ->get();


    //     // Ambil data yang ingin diekspor (misalnya data pengguna)
    //     $data = ['name' => 'John Doe', 'email' => 'john@example.com'];

    //     // Buat view untuk data yang akan dimasukkan ke PDF
    //     $pdf = PDF::loadView('nilai.TEST_filter_siswa', $data);

    //     // Mengunduh PDF
    //     return $pdf->download('exported-file.pdf');
    //     return dd($request->all());
    // }

    public function exportPdf(Request $request)
    {
        $kelasId = $request->input('kelas_id');
        $mataPelajaran = $request->input('mataPelajaran');

        $tugas_dari_guru = Tugas_dari_guru::all();
        $tugas_dari_siswa = Tugas_dari_siswa::all();

        $test = Siswa::with(['tugas_dari_siswa.tugas_dari_guru', 'kelas'])
            ->where('kelas_id', $kelasId)
            ->orderBy('id', 'desc')
            ->get();
                // ->orderBy('nama', 'asc') urut nama dari A-Z


        $tugas = Tugas_dari_guru::with('tugas_dari_siswa.siswa')
            ->whereHas('kelas', function ($query) use ($kelasId) {
                if ($kelasId) {
                    $query->where('id', $kelasId);
                }
            })
            ->when($mataPelajaran, function ($query) use ($mataPelajaran) {
                return $query->where('title', $mataPelajaran);
            })
            ->get();

        // Kirim semua data yang dibutuhkan oleh Blade view
        $data = [
            'kelasId' => $kelasId,
            'mataPelajaran' => $mataPelajaran,
            'tugas' => $tugas,
        ];

        // // Load view dan generate PDF
        // $pdf = PDF::loadView('nilai.pdf_download', $data);
        $test2 = Tugas_dari_guru::where('kelas_id', $kelasId)
                        ->pluck('title')
                        ->unique();

        // // Unduh file PDF
        // return $pdf->download('exported-file.pdf');
        return view('nilai.pdf_download', compact('tugas','kelasId', 'mataPelajaran','tugas_dari_guru','tugas_dari_siswa','test','test2'));
    }


    public function exportPdf2(Request $request)
    {
        $kelasId = $request->input('kelas_id');
        $mataPelajaran = $request->input('mataPelajaran');

        $tugas_dari_guru = Tugas_dari_guru::all();
        $tugas_dari_siswa = Tugas_dari_siswa::all();

        $test = Siswa::with(['tugas_dari_siswa.tugas_dari_guru', 'kelas'])
            ->where('kelas_id', $kelasId)
            ->orderBy('id', 'desc')
            ->get();

        $tugas = Tugas_dari_guru::with('tugas_dari_siswa.siswa')
            ->whereHas('kelas', function ($query) use ($kelasId) {
                if ($kelasId) {
                    $query->where('id', $kelasId);
                }
            })
            ->when($mataPelajaran, function ($query) use ($mataPelajaran) {
                return $query->where('title', $mataPelajaran);
            })
            ->get();

        $test2 = Tugas_dari_guru::where('kelas_id', $kelasId)
            ->pluck('title')
            ->unique();

        // satukan semua data ke array
        $data = compact('tugas','kelasId','mataPelajaran','tugas_dari_guru','tugas_dari_siswa','test','test2');

        // kalau mau generate PDF
        $pdf = PDF::loadView('nilai.pdf_download', $data);

        // return PDF download
        return $pdf->download('exported-file.pdf');

        // sementara untuk debug, tampilkan view di browser
        // return view('nilai.pdf_download', $data);
    }


}
