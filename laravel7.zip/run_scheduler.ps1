Start-Process -FilePath "C:\xampp\php\php.exe" -ArgumentList "artisan schedule:run" -WorkingDirectory "C:\xampp\htdocs\laravel7" -WindowStyle Hidden -NoNewWindow
