<!DOCTYPE html>
<html>
<head>
    <title>Export PDF</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
    </style>
</head>
<body>
    <h1>Data Pengguna</h1>
    <p>Nama: {{ $name }}</p>
    <p>Email: {{ $email }}</p>
</body>
</html>
